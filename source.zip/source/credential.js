module.exports = {
  owaID: 'fa7d80c48643dfadde2cced1b1be6ca1',
  appID: 'c47acb4ad586f4224feb794843d48138',
}
